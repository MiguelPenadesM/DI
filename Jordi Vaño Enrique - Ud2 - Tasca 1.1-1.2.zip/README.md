# DI
Desenrotllament d'interficies
## JavaFX
Prácticas 1.1 y 1.2:https://github.com/jordivano17/DI/tree/main/Pruebas/src/main/java/com/example/pruebas
